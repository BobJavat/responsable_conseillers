<?php
phpinfo();
xdebug_info();